import fresh_tomatoes
import media

arrival = media.Movie("Arrival",
                                "Linguistics professor Louise Banks (Amy Adams) leads an elite team of investigators when gigantic spaceships touch down in 12 locations around the world. As nations teeter on the verge of global war, Banks and her crew must race against time to find a way to communicate with the extraterrestrial visitors. Hoping to unravel the mystery, she takes a chance that could threaten her life and quite possibly all of mankind.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/09112206/81dfbc0821bb4145cea6f9849f510b812855e88ffc04f48c45b0cf7ae40d8886-1536x1536.jpg",
                                "https://www.youtube.com/watch?v=tFMo3UJ4B4g")

fences = media.Movie("Fences",
                                "Troy Maxson, a former star player in the Negro Leagues, lives with his wife Rose and teenage son Cory in Pittsburgh in 1957. Troy is bitter about missing the integration of professional baseball, and his caustic attitudes toward life and race relations taint his relationship with Cory, an aspiring football player.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/17094631/1d551a24bea0151ddd2b632ad54bf50dc60796bddfeb2859a151803ed8908319-370x492.jpg",
                                "https://www.youtube.com/watch?v=a2m6Jvp0bUw")

hacksaw_ridge = media.Movie("Hacksaw Ridge",
                                "Desmond Doss, a Seventh-day Adventist who endured a troubled childhood in rural Virginia, enlists in the army during World War II despite his pacifist beliefs. After Desmond's desire to serve as an unarmed medic is approved by military officials, he is sent to the Pacific arena, where he saves dozens of lives during the Battle of Okinawa.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/17095324/372cc01e1e49ba22a30f69a1af8a1e417cf8a592795f48a4d160bedfe337c756-370x492.jpg",
                                "https://www.youtube.com/watch?v=s2-1hz1juBI")

hell_or_high_water = media.Movie("Hell Or High Water",
                                "Toby and his ex-con brother Tanner rob branches of a West Texas bank to obtain enough money to prevent the foreclosure of their family ranch. Crafty Texas Ranger Marcus Hamilton is soon on the case, his last before he retires, and as Marcus zeroes in on them, the brothers attempt one last score.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/09141122/583b8c8125e72c2ab49b128f8b9203420d92f4dcf3ae3b72a4178910a8537e67-370x492.jpg",
                                "https://www.youtube.com/watch?v=JQoqsKoJVDw")

hidden_figures = media.Movie("Hidden Figures",
                                "In the early 1960s, as the U.S. seeks to surpass the Soviet Union in the space race, three mathematically and technologically gifted African-American women must cope with racism and sexism while performing vital tasks at NASA's segregated Virginia facilities.",
                                "http://oscar-prod-images.bls-customers.com/wp-content/uploads/2017/01/17095656/9f77f79970b8b70f19d31bb58d8dfeb64152633fef7fe642e55c9c4590b50b96-370x492.jpg",
                                "https://www.youtube.com/watch?v=5wfrDhgUMGI")

la_la_land = media.Movie("La La Land",
                                "Aspiring actress Mia and jazz pianist Sebastian struggle to realize their dreams in Los Angeles despite the often soul-crushing commercial nature of show business. As they endure rejection and forge unexpected paths to stardom, the young couple also strives to sustain the love they were surprised to find.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/23214937/87a4ac01d43c980a069b516ae0bf5dab4e1c89e2ee4c676862d765c092337338-370x492.jpg",
                                "https://www.youtube.com/watch?v=0pdqf4P9MB8")

lion = media.Movie("Lion",
                                "After being separated from his family in India, five-year-old Saroo is adopted by an Australian couple who raise him with great love. As an adult, however, Saroo is troubled by resurfacing memories of his birth family and employs new worldwide technology to locate them.",
                                "http://oscar-prod-images.bls-customers.com/wp-content/uploads/2017/01/17101123/b708483ae9ebf2eddeae030af0c751485ac89540db02e24aae571de6de4e523c-370x492.jpg",
                                "https://www.youtube.com/watch?v=-RNI9o06vqo")

manchester_by_the_sea = media.Movie("Manchester By The Sea",
                                "When his beloved older brother dies, handyman Lee Chandler returns to his hometown, a close-knit fishing community in Massachusetts. There, Lee struggles to cope with his current grief and a tragedy from his past while also summoning the strength to comfort his teenage nephew, who has been left in his care.",
                                "http://oscar-prod-images.bls-customers.com/wp-content/uploads/2017/01/10084014/ff75b81baaf98d36793dd79b5ecc98d9c3965def4b9e26bc0acaea6caa233f6d-370x492.jpg",
                                "https://www.youtube.com/watch?v=gsVoD0pTge0")

moonlight = media.Movie("Moonlight",
                                "As he grows from childhood to adulthood in Miami, a young black man grapples with surviving the poverty and drugs that pervade his neighborhood, establishing his own identity and accepting his sexuality. Under the influences of his drug-addicted mother, a kindly surrogate father and a conflicted best friend, the youth finds his way in life.",
                                "https://s3.amazonaws.com/oscars-img-abc/wp-content/uploads/2017/01/10085121/0630d6a603c4c5be965adc27225917cabddb5fed36db77cd10641af43f9d6ae1-370x492.jpg",
                                "https://www.youtube.com/watch?v=9NJj12tJzqc")

movies = [arrival, fences, hacksaw_ridge, hell_or_high_water, hidden_figures, la_la_land, lion, manchester_by_the_sea, moonlight]
fresh_tomatoes.open_movies_page(movies)
